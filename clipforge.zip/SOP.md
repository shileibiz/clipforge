# ClipForge SOP — AI 全自动视频剪辑标准作业流程

> 执行者:Claude Code(以下简称 CC)。人类只做两件事:给选题、看成片。
> 对应旧人工流程:写稿→录音→找无版权素材→剪辑拼接→做字幕→检查→上传。
> 现在全部由 CC 调用 `clipforge.py` 完成,人只在 Gate 处介入。

---

## 0. 前置条件(一次性)

1. `pip install edge-tts requests pyyaml`,系统装好 `ffmpeg`
2. 项目根目录放 `.env`(参考 `.env.example`):
   - `PEXELS_API_KEY`(免费申请,主素材源,视频+图片)
   - `PIXABAY_API_KEY`(免费,视频兜底源)
   - `DEEPSEEK_API_KEY`(可选,自动提取英文搜索词)
   - `COMFYUI_API`(可选,本地生图终极兜底,对接你 4060 上的 ComfyUI HTTP API)
3. 字幕字体:Linux 需要 `Noto Sans CJK SC`(`apt install fonts-noto-cjk`)

## 1. 流水线总览

```
选题 → [CC写稿+分场景] → project.yaml
      → tts     (edge-tts 逐场景合成语音, 记录精确时长 → manifest.json)
      → assets  (Pexels视频 → Pixabay视频 → Pexels图片 → ComfyUI生图, 逐级兜底, 去重)
      → subs    (逐场景SRT按时长偏移合并为全片 final.srt)
      → render  (FFmpeg: 视频裁切1080p / 图片Ken Burns → 逐场景带音轨渲染 → concat → 烧字幕 + BGM)
      → check   (ffprobe QC: 时长差<1.5s、分辨率、音轨、srt/credits 齐全)
      → output/final.mp4 + final.srt + thumbnail.jpg + assets/credits.md
```

一条命令跑全程:`python clipforge.py all <项目目录>`
每个阶段幂等可断点重跑:已完成的场景自动跳过,失败即 fail-fast 并打印原因。

## 2. CC 执行步骤

### Step 1 — 写稿并结构化(CC 生成 project.yaml)
1. `python clipforge.py init projects/<slug>` 生成脚手架
2. CC 按选题写口播稿,**写稿即分场景**,每场景规则:
   - 一个场景 = 一个画面 = 20~60 字口播(约 5~15 秒)
   - 每场景给 1~2 个**英文** `keywords`(名词优先、画面感优先:`stock chart` 优于 `finance concept`)
   - `asset_type`: 动态内容用 `video`,静态概念用 `image`,拿不准用 `auto`
3. 全片 8~20 个场景为宜(2~5 分钟成片)

**🚪 Gate 1(可选):** 人工扫一眼文稿。批量生产模式下可跳过。

### Step 2 — 自动执行
```bash
python clipforge.py all projects/<slug>
```
CC 观察输出,任一阶段失败按 §3 处置后重跑同一条命令(幂等续跑)。

### Step 3 — QC 与交付
- `check` 通过后,产物在 `output/`:`final.mp4`、`final.srt`(软字幕备用)、`thumbnail.jpg`
- CC 汇报:成片时长、场景数、素材来源统计(credits.md)、QC 报告路径

**🚪 Gate 2(必过):** 人工看一遍成片(重点:素材与文案是否语义错位、字幕断句)。
通过 → 上传 YouTube/B站;不通过 → 只改问题场景的 keywords 或 text,删掉对应
`assets/scene_XX.*`、`build/clip_XX.mp4` 与 manifest 中该场景的 `asset_ok`,重跑 `all`。

## 3. 故障处置表(CC 按表自愈,不要瞎猜)

| 症状 | 原因 | 处置 |
|---|---|---|
| tts 阶段音频时长 < 0.5s | edge-tts 网络被墙/波动 | 走代理重跑;仍失败换 voice 重试一次 |
| assets 全源失败 | keywords 太抽象/中文 | 换更具体的英文名词性 keywords 重跑 assets |
| Pexels 429 | 免费额度 200次/小时 | sleep 后重跑,或临时只用 Pixabay |
| 字幕乱码/方框 | 缺 CJK 字体 | `apt install fonts-noto-cjk` |
| duration_delta > 1.5s | 某场景 clip 渲染截断 | 删对应 build/clip_XX.mp4 重跑 render |
| 竖版需求(抖音/Shorts) | — | project.yaml 设 `orientation: portrait` |

## 4. 禁止重犯(错误一次,规则一条 — 持续追加)

1. keywords 必须是英文、名词性、有画面感;禁止用抽象概念词(如 `success`, `future`)直接搜素材
2. 同一素材 id 全片禁止复用(工具已内置去重,禁止绕过)
3. 任何阶段禁止手动改 manifest.json 里的时长字段 —— 时长以 ffprobe 为准
4. 上传前必须确认 assets/credits.md 存在(素材可溯源是底线)
5. (追加于此…)

## 5. 与现有资产的衔接

- **TubeForge**:ClipForge 就是 TubeForge 的"渲染引擎层",TubeForge 负责选题/脚本批量生成,产出 project.yaml 后直接喂给 ClipForge
- **x-daily**:成片可走既有 "草稿→Telegram 通知→人工发布" 模式上 B 站/抖音
- **ComfyUI(4060)**:作为素材终极兜底,改 `comfyui_image()` 一个函数即可对接你现有 HTTP 封装
