#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ClipForge — AI 全自动视频剪辑流水线(供 Claude Code 调用)

流程: 文字稿 → TTS(edge-tts) → 无版权素材搜索(Pexels/Pixabay/ComfyUI兜底)
      → 字幕SRT → FFmpeg 逐场景渲染+拼接+烧字幕+BGM → QC 检查 → 成片

用法:
  python clipforge.py init  <项目目录>          # 生成项目脚手架 project.yaml
  python clipforge.py tts   <项目目录>          # 逐场景合成语音 + 记录时长
  python clipforge.py assets <项目目录>         # 逐场景搜索并下载无版权素材
  python clipforge.py subs  <项目目录>          # 生成全片 SRT
  python clipforge.py render <项目目录>         # FFmpeg 渲染成片
  python clipforge.py check <项目目录>          # QC 检查(时长/分辨率/音轨)
  python clipforge.py all   <项目目录>          # 按顺序跑完整条流水线
  python clipforge.py clean <项目目录>          # 清理 build 产物(保留素材)

环境变量(.env 或 shell 导出):
  PEXELS_API_KEY    必填其一   https://www.pexels.com/api/
  PIXABAY_API_KEY   必填其一   https://pixabay.com/api/docs/
  DEEPSEEK_API_KEY  可选       场景未写 keywords 时自动提取英文搜索词
  COMFYUI_API       可选       本地生图兜底,如 http://192.168.1.10:8188

依赖: pip install edge-tts requests pyyaml   (系统需装 ffmpeg/ffprobe)
"""

import argparse
import asyncio
import json
import math
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

try:
    import yaml
except ImportError:
    print("缺少依赖: pip install pyyaml requests edge-tts", file=sys.stderr)
    sys.exit(1)

import requests

# ---------------- 全局常量 ----------------
W, H, FPS = 1920, 1080, 30
CRF = 20
PRESET = "medium"
SUB_STYLE = (
    "FontName=Noto Sans CJK SC,FontSize=16,PrimaryColour=&H00FFFFFF,"
    "OutlineColour=&H00000000,BorderStyle=1,Outline=2,Shadow=0,"
    "MarginV=40,Alignment=2"
)

# ---------------- 基础工具 ----------------

def log(msg):
    print(f"[clipforge] {msg}", flush=True)


def die(msg):
    print(f"[clipforge][FATAL] {msg}", file=sys.stderr)
    sys.exit(1)


def run(cmd, quiet=True):
    """执行外部命令,失败即终止(fail-fast,便于 CC 定位问题)。"""
    r = subprocess.run(cmd, capture_output=quiet, text=True)
    if r.returncode != 0:
        err = (r.stderr or "")[-2000:] if quiet else ""
        die(f"命令失败: {' '.join(map(str, cmd))}\n{err}")
    return r


def load_env(proj: Path):
    """加载项目目录或当前目录下的 .env(不覆盖已有环境变量)。"""
    for p in (proj / ".env", Path(".env")):
        if p.exists():
            for line in p.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def load_project(proj: Path) -> dict:
    f = proj / "project.yaml"
    if not f.exists():
        die(f"找不到 {f},先执行 init")
    cfg = yaml.safe_load(f.read_text(encoding="utf-8"))
    if not cfg.get("scenes"):
        die("project.yaml 中 scenes 为空")
    for i, sc in enumerate(cfg["scenes"]):
        if not sc.get("text", "").strip():
            die(f"场景 {i+1} 缺少 text")
    return cfg


def manifest_path(proj: Path) -> Path:
    return proj / "build" / "manifest.json"


def load_manifest(proj: Path) -> dict:
    p = manifest_path(proj)
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {"scenes": {}}


def save_manifest(proj: Path, m: dict):
    p = manifest_path(proj)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding="utf-8")


def ffprobe_json(path: Path) -> dict:
    r = run(["ffprobe", "-v", "quiet", "-print_format", "json",
             "-show_format", "-show_streams", str(path)])
    return json.loads(r.stdout)


def media_duration(path: Path) -> float:
    return float(ffprobe_json(path)["format"]["duration"])


def fmt_srt_time(t: float) -> str:
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


# ---------------- init ----------------

TEMPLATE_YAML = """\
# ClipForge 项目配置 —— 一个场景 = 一段口播 + 一个画面素材
title: 示例:三分钟看懂复利
voice: zh-CN-YunxiNeural        # edge-tts 声音, 英文可用 en-US-AndrewNeural
rate: "+8%"                     # 语速微调
subtitle_mode: sentence         # sentence=按句均摊时间(中文推荐) / word=edge-tts词级时间轴
bgm: ""                         # 可选: BGM 文件路径(相对项目目录), 自动降到 12% 音量循环
bgm_volume: 0.12
orientation: landscape          # landscape=1920x1080 / portrait=1080x1920(竖版)

scenes:
  - text: 你有没有想过,为什么巴菲特99%的财富是在50岁之后才赚到的?答案只有两个字:复利。
    keywords: [money growth, compound interest]   # 英文搜索词,留空则用 DeepSeek 自动提取
    asset_type: video                             # video / image / auto
  - text: 假设你每个月定投一千元,年化收益百分之八,三十年后你会拥有接近一百五十万。
    keywords: [stock chart, investment]
    asset_type: video
  - text: 时间才是复利最重要的变量。越早开始,雪球滚得越大。
    keywords: [snowball, winter mountain]
    asset_type: video
"""


def cmd_init(proj: Path):
    proj.mkdir(parents=True, exist_ok=True)
    for d in ("audio", "assets", "build", "output"):
        (proj / d).mkdir(exist_ok=True)
    f = proj / "project.yaml"
    if f.exists():
        log(f"{f} 已存在,跳过")
    else:
        f.write_text(TEMPLATE_YAML, encoding="utf-8")
        log(f"已生成 {f},编辑 scenes 后执行: python clipforge.py all {proj}")


# ---------------- tts ----------------

def split_sentences(text: str):
    """中英混合分句,用于 sentence 字幕模式。"""
    parts = re.split(r"(?<=[。!?!?;;])\s*", text.strip())
    parts = [p.strip() for p in parts if p.strip()]
    # 过长句子按逗号二次切分,保证单条字幕不超过 ~28 字
    out = []
    for p in parts:
        if len(p) <= 28:
            out.append(p)
        else:
            for q in re.split(r"(?<=[,,、])\s*", p):
                if q.strip():
                    out.append(q.strip())
    return out or [text.strip()]


async def _tts_one(text, voice, rate, mp3: Path, srt: Path, mode: str):
    import edge_tts
    comm = edge_tts.Communicate(text, voice, rate=rate)
    sub = edge_tts.SubMaker()
    with open(mp3, "wb") as f:
        async for chunk in comm.stream():
            if chunk["type"] == "audio":
                f.write(chunk["data"])
            elif chunk["type"] == "WordBoundary":
                try:
                    sub.feed(chunk)
                except Exception:
                    pass
    if mode == "word":
        try:
            srt.write_text(sub.get_srt(), encoding="utf-8")
            return
        except Exception:
            pass  # 回落到 sentence 模式
    # sentence 模式: 按句子字符数均摊本场景音频时长
    dur = media_duration(mp3)
    sents = split_sentences(text)
    total_chars = sum(len(s) for s in sents) or 1
    t, lines = 0.0, []
    for i, s in enumerate(sents, 1):
        d = dur * len(s) / total_chars
        lines.append(f"{i}\n{fmt_srt_time(t)} --> {fmt_srt_time(min(t + d, dur))}\n{s}\n")
        t += d
    srt.write_text("\n".join(lines), encoding="utf-8")


def cmd_tts(proj: Path):
    cfg = load_project(proj)
    m = load_manifest(proj)
    voice = cfg.get("voice", "zh-CN-YunxiNeural")
    rate = cfg.get("rate", "+0%")
    mode = cfg.get("subtitle_mode", "sentence")
    for i, sc in enumerate(cfg["scenes"], 1):
        key = f"{i:02d}"
        mp3 = proj / "audio" / f"scene_{key}.mp3"
        srt = proj / "audio" / f"scene_{key}.srt"
        if mp3.exists() and m["scenes"].get(key, {}).get("audio_ok"):
            log(f"场景{key} 音频已存在,跳过")
            continue
        log(f"场景{key} TTS: {sc['text'][:24]}…")
        asyncio.run(_tts_one(sc["text"], sc.get("voice", voice),
                             sc.get("rate", rate), mp3, srt, mode))
        dur = media_duration(mp3)
        if dur < 0.5:
            die(f"场景{key} 音频异常(时长 {dur:.2f}s),检查网络或文本")
        m["scenes"].setdefault(key, {})
        m["scenes"][key].update({"audio_ok": True, "duration": round(dur, 3)})
        save_manifest(proj, m)
        log(f"场景{key} 完成, 时长 {dur:.1f}s")
    total = sum(s["duration"] for s in m["scenes"].values())
    log(f"TTS 全部完成, 总口播时长 {total:.1f}s")


# ---------------- assets ----------------

def extract_keywords_deepseek(text: str):
    key = os.environ.get("DEEPSEEK_API_KEY")
    if not key:
        return []
    try:
        r = requests.post(
            "https://api.deepseek.com/chat/completions",
            headers={"Authorization": f"Bearer {key}"},
            json={"model": "deepseek-chat", "temperature": 0.2, "messages": [{
                "role": "user",
                "content": ("为下面这句视频口播提取2个适合在免版权素材站搜索B-roll的英文关键词,"
                            "只输出JSON数组,不要解释:\n" + text)}]},
            timeout=30)
        content = r.json()["choices"][0]["message"]["content"]
        arr = json.loads(re.search(r"\[.*\]", content, re.S).group(0))
        return [str(a) for a in arr][:2]
    except Exception as e:
        log(f"DeepSeek 关键词提取失败({e}),回落为通用词")
        return []


def pexels_video(kw, used: set):
    key = os.environ.get("PEXELS_API_KEY")
    if not key:
        return None
    try:
        r = requests.get("https://api.pexels.com/videos/search",
                         headers={"Authorization": key},
                         params={"query": kw, "per_page": 8,
                                 "orientation": "landscape"}, timeout=30)
        for v in r.json().get("videos", []):
            if f"pexels-v-{v['id']}" in used:
                continue
            files = sorted([f for f in v["video_files"]
                            if f.get("width") and f["width"] >= 1280],
                           key=lambda f: -f["width"])
            if files:
                return {"kind": "video", "url": files[0]["link"],
                        "id": f"pexels-v-{v['id']}", "ext": ".mp4",
                        "credit": f"Pexels video {v['url']}"}
    except Exception as e:
        log(f"Pexels 视频搜索失败: {e}")
    return None


def pexels_photo(kw, used: set):
    key = os.environ.get("PEXELS_API_KEY")
    if not key:
        return None
    try:
        r = requests.get("https://api.pexels.com/v1/search",
                         headers={"Authorization": key},
                         params={"query": kw, "per_page": 8,
                                 "orientation": "landscape"}, timeout=30)
        for p in r.json().get("photos", []):
            if f"pexels-p-{p['id']}" in used:
                continue
            return {"kind": "image", "url": p["src"]["large2x"],
                    "id": f"pexels-p-{p['id']}", "ext": ".jpg",
                    "credit": f"Pexels photo {p['url']}"}
    except Exception as e:
        log(f"Pexels 图片搜索失败: {e}")
    return None


def pixabay_video(kw, used: set):
    key = os.environ.get("PIXABAY_API_KEY")
    if not key:
        return None
    try:
        r = requests.get("https://pixabay.com/api/videos/",
                         params={"key": key, "q": kw, "per_page": 8}, timeout=30)
        for v in r.json().get("hits", []):
            if f"pixabay-v-{v['id']}" in used:
                continue
            vf = v["videos"].get("large") or v["videos"].get("medium")
            if vf and vf.get("url"):
                return {"kind": "video", "url": vf["url"],
                        "id": f"pixabay-v-{v['id']}", "ext": ".mp4",
                        "credit": f"Pixabay video {v.get('pageURL','')}"}
    except Exception as e:
        log(f"Pixabay 视频搜索失败: {e}")
    return None


def comfyui_image(prompt: str, out: Path):
    """本地 ComfyUI 兜底生图。依赖你已有的 HTTP API 封装:
    POST {COMFYUI_API}/generate  {"prompt": "..."} → 返回图片二进制。
    如你的封装不同,只需改这一个函数。"""
    api = os.environ.get("COMFYUI_API")
    if not api:
        return False
    try:
        r = requests.post(f"{api.rstrip('/')}/generate",
                          json={"prompt": prompt}, timeout=300)
        if r.status_code == 200 and r.content:
            out.write_bytes(r.content)
            return True
    except Exception as e:
        log(f"ComfyUI 生图失败: {e}")
    return False


def download(url: str, out: Path):
    with requests.get(url, stream=True, timeout=120) as r:
        r.raise_for_status()
        with open(out, "wb") as f:
            for chunk in r.iter_content(1 << 16):
                f.write(chunk)


def cmd_assets(proj: Path):
    cfg = load_project(proj)
    m = load_manifest(proj)
    used = {s.get("asset_id") for s in m["scenes"].values() if s.get("asset_id")}
    credits = []
    for i, sc in enumerate(cfg["scenes"], 1):
        key = f"{i:02d}"
        rec = m["scenes"].setdefault(key, {})
        if rec.get("asset_ok") and rec.get("asset") and (proj / rec["asset"]).exists():
            log(f"场景{key} 素材已存在,跳过")
            continue
        kws = sc.get("keywords") or extract_keywords_deepseek(sc["text"]) or ["abstract background"]
        want = sc.get("asset_type", "auto")
        found = None
        for kw in kws:
            if want in ("video", "auto"):
                found = pexels_video(kw, used) or pixabay_video(kw, used)
            if not found and want in ("image", "auto"):
                found = pexels_photo(kw, used)
            if found:
                log(f"场景{key} 命中素材 [{kw}] → {found['id']}")
                break
        out = proj / "assets" / f"scene_{key}"
        if found:
            out = out.with_suffix(found["ext"])
            download(found["url"], out)
            rec.update({"asset": str(out.relative_to(proj)), "asset_kind": found["kind"],
                        "asset_id": found["id"], "asset_ok": True})
            used.add(found["id"])
            credits.append(f"scene_{key}: {found['credit']}")
        else:
            # 兜底: ComfyUI 生图
            out = out.with_suffix(".png")
            prompt = ", ".join(kws) + ", cinematic, high quality, 16:9"
            if comfyui_image(prompt, out):
                rec.update({"asset": str(out.relative_to(proj)), "asset_kind": "image",
                            "asset_id": f"comfyui-{key}", "asset_ok": True})
                credits.append(f"scene_{key}: ComfyUI 本地生成 ({prompt})")
                log(f"场景{key} ComfyUI 兜底生图完成")
            else:
                die(f"场景{key} 所有素材源均失败,关键词: {kws} —— "
                    f"请检查 API key,或换 keywords 后重跑 assets")
        save_manifest(proj, m)
    if credits:
        (proj / "assets" / "credits.md").write_text(
            "# 素材来源(免版权)\n\n" + "\n".join(f"- {c}" for c in credits) + "\n",
            encoding="utf-8")
    log("素材阶段完成, 来源已写入 assets/credits.md")


# ---------------- subs ----------------

def parse_srt(path: Path):
    items = []
    blocks = re.split(r"\n\s*\n", path.read_text(encoding="utf-8").strip())
    for b in blocks:
        lines = b.strip().splitlines()
        if len(lines) >= 3:
            mm = re.match(r"([\d:,]+)\s*-->\s*([\d:,]+)", lines[1])
            if mm:
                def to_s(t):
                    h, mn, rest = t.split(":")
                    s, ms = rest.split(",")
                    return int(h) * 3600 + int(mn) * 60 + int(s) + int(ms) / 1000
                items.append((to_s(mm.group(1)), to_s(mm.group(2)),
                              " ".join(lines[2:])))
    return items


def cmd_subs(proj: Path):
    cfg = load_project(proj)
    m = load_manifest(proj)
    offset, idx, out_lines = 0.0, 0, []
    for i in range(1, len(cfg["scenes"]) + 1):
        key = f"{i:02d}"
        rec = m["scenes"].get(key) or die(f"场景{key} 未跑 tts")
        srt = proj / "audio" / f"scene_{key}.srt"
        if not srt.exists():
            die(f"缺少 {srt},先跑 tts")
        for st, en, txt in parse_srt(srt):
            idx += 1
            out_lines.append(f"{idx}\n{fmt_srt_time(st + offset)} --> "
                             f"{fmt_srt_time(en + offset)}\n{txt}\n")
        offset += rec["duration"]
    final = proj / "build" / "final.srt"
    final.parent.mkdir(exist_ok=True)
    final.write_text("\n".join(out_lines), encoding="utf-8")
    log(f"全片字幕已生成: {final} (共 {idx} 条, 总长 {offset:.1f}s)")


# ---------------- render ----------------

def scene_size(cfg):
    return (1080, 1920) if cfg.get("orientation") == "portrait" else (W, H)


def render_scene(proj: Path, cfg, key: str, rec: dict) -> Path:
    w, h = scene_size(cfg)
    asset = proj / rec["asset"]
    audio = proj / "audio" / f"scene_{key}.mp3"
    out = proj / "build" / f"clip_{key}.mp4"
    dur = rec["duration"]
    if out.exists() and abs(media_duration(out) - dur) < 0.5:
        log(f"场景{key} 片段已渲染,跳过")
        return out
    if rec["asset_kind"] == "video":
        vf = (f"scale={w}:{h}:force_original_aspect_ratio=increase,"
              f"crop={w}:{h},fps={FPS},setsar=1")
        run(["ffmpeg", "-y", "-stream_loop", "-1", "-i", str(asset),
             "-i", str(audio), "-t", f"{dur:.3f}",
             "-filter_complex", f"[0:v]{vf}[v]",
             "-map", "[v]", "-map", "1:a",
             "-c:v", "libx264", "-preset", PRESET, "-crf", str(CRF),
             "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
             "-shortest", str(out)])
    else:  # 图片 → Ken Burns 缓推
        frames = max(int(dur * FPS), 1)
        vf = (f"scale={w*2}:-2,"
              f"zoompan=z='min(zoom+0.0006,1.15)':d={frames}"
              f":x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)'"
              f":s={w}x{h}:fps={FPS},setsar=1")
        run(["ffmpeg", "-y", "-loop", "1", "-i", str(asset),
             "-i", str(audio), "-t", f"{dur:.3f}",
             "-filter_complex", f"[0:v]{vf}[v]",
             "-map", "[v]", "-map", "1:a",
             "-c:v", "libx264", "-preset", PRESET, "-crf", str(CRF),
             "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
             "-shortest", str(out)])
    log(f"场景{key} 渲染完成 ({dur:.1f}s)")
    return out


def cmd_render(proj: Path):
    cfg = load_project(proj)
    m = load_manifest(proj)
    build = proj / "build"
    clips = []
    for i in range(1, len(cfg["scenes"]) + 1):
        key = f"{i:02d}"
        rec = m["scenes"].get(key)
        if not (rec and rec.get("audio_ok") and rec.get("asset_ok")):
            die(f"场景{key} 前置阶段未完成(tts/assets)")
        clips.append(render_scene(proj, cfg, key, rec))
    # 拼接
    lst = build / "concat.txt"
    lst.write_text("".join(f"file '{c.resolve()}'\n" for c in clips), encoding="utf-8")
    merged = build / "merged.mp4"
    run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(lst),
         "-c", "copy", str(merged)])
    # 字幕(烧录) + BGM
    srt = build / "final.srt"
    if not srt.exists():
        cmd_subs(proj)
    final = proj / "output" / "final.mp4"
    final.parent.mkdir(exist_ok=True)
    srt_esc = str(srt.resolve()).replace("\\", "/").replace(":", "\\:").replace("'", "\\'")
    sub_filter = f"subtitles='{srt_esc}':force_style='{SUB_STYLE}'"
    bgm = cfg.get("bgm", "")
    if bgm and (proj / bgm).exists():
        vol = cfg.get("bgm_volume", 0.12)
        run(["ffmpeg", "-y", "-i", str(merged),
             "-stream_loop", "-1", "-i", str(proj / bgm),
             "-filter_complex",
             f"[0:v]{sub_filter}[v];"
             f"[1:a]volume={vol}[bg];[0:a][bg]amix=inputs=2:duration=first:dropout_transition=2[a]",
             "-map", "[v]", "-map", "[a]",
             "-c:v", "libx264", "-preset", PRESET, "-crf", str(CRF),
             "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
             "-shortest", str(final)])
    else:
        run(["ffmpeg", "-y", "-i", str(merged),
             "-vf", sub_filter,
             "-c:v", "libx264", "-preset", PRESET, "-crf", str(CRF),
             "-pix_fmt", "yuv420p", "-c:a", "copy", str(final)])
    # 顺带出封面帧 + 独立 srt(平台软字幕可另传)
    run(["ffmpeg", "-y", "-i", str(final), "-ss", "1", "-frames:v", "1",
         str(proj / "output" / "thumbnail.jpg")])
    shutil.copy(srt, proj / "output" / "final.srt")
    log(f"成片输出: {final}")


# ---------------- check ----------------

def cmd_check(proj: Path):
    cfg = load_project(proj)
    m = load_manifest(proj)
    final = proj / "output" / "final.mp4"
    if not final.exists():
        die("找不到成片,先跑 render")
    info = ffprobe_json(final)
    vdur = float(info["format"]["duration"])
    adur_total = sum(s["duration"] for s in m["scenes"].values())
    vstreams = [s for s in info["streams"] if s["codec_type"] == "video"]
    astreams = [s for s in info["streams"] if s["codec_type"] == "audio"]
    w, h = scene_size(cfg)
    report = {
        "file": str(final),
        "duration": round(vdur, 2),
        "expected_duration": round(adur_total, 2),
        "duration_delta": round(abs(vdur - adur_total), 2),
        "resolution": f"{vstreams[0]['width']}x{vstreams[0]['height']}" if vstreams else "none",
        "has_audio": bool(astreams),
        "srt_exists": (proj / "output" / "final.srt").exists(),
        "credits_exists": (proj / "assets" / "credits.md").exists(),
    }
    problems = []
    if report["duration_delta"] > 1.5:
        problems.append(f"成片与口播总时长差 {report['duration_delta']}s > 1.5s")
    if vstreams and (vstreams[0]["width"], vstreams[0]["height"]) != (w, h):
        problems.append(f"分辨率 {report['resolution']} != {w}x{h}")
    if not astreams:
        problems.append("成片无音轨")
    report["problems"] = problems
    report["pass"] = not problems
    (proj / "build" / "qc_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    log(json.dumps(report, ensure_ascii=False, indent=2))
    if problems:
        die("QC 未通过: " + "; ".join(problems))
    log("QC 通过 ✅ 可上传 output/final.mp4 (+ final.srt / thumbnail.jpg)")


# ---------------- clean / all ----------------

def cmd_clean(proj: Path):
    shutil.rmtree(proj / "build", ignore_errors=True)
    (proj / "build").mkdir(exist_ok=True)
    log("build 已清空(音频与素材保留,manifest 已重置)")


def cmd_all(proj: Path):
    cmd_tts(proj)
    cmd_assets(proj)
    cmd_subs(proj)
    cmd_render(proj)
    cmd_check(proj)


# ---------------- main ----------------

def main():
    ap = argparse.ArgumentParser(description="ClipForge — AI 全自动剪辑流水线")
    ap.add_argument("command", choices=["init", "tts", "assets", "subs",
                                        "render", "check", "all", "clean"])
    ap.add_argument("project", help="项目目录")
    args = ap.parse_args()
    proj = Path(args.project)
    load_env(proj)
    if args.command != "init" and not shutil.which("ffmpeg"):
        die("未找到 ffmpeg,请先安装")
    {"init": cmd_init, "tts": cmd_tts, "assets": cmd_assets, "subs": cmd_subs,
     "render": cmd_render, "check": cmd_check, "all": cmd_all,
     "clean": cmd_clean}[args.command](proj)


if __name__ == "__main__":
    main()
